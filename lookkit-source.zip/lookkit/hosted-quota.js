// Daily render counters only: no photos, raw IP addresses or API keys.
// Separate from the retired lifetime ledger; never reuse this namespace elsewhere.
export const LEDGER_KEY='lookkit:andrea:daily-renders:v1';
export const GLOBAL_LIMIT=10, IP_LIMIT=3, PER_UPLOAD=3;
export const RESERVE_SCRIPT=`
local now = tonumber(redis.call('TIME')[1])
local day = math.floor((now + 7200) / 86400)
local resets = (day + 1) * 86400 - 7200
local key = KEYS[1] .. ':' .. day
local used = tonumber(redis.call('HGET', key, 'used') or '0')
local visitor = tonumber(redis.call('HGET', key, ARGV[1]) or '0')
if not used or not visitor or used < 0 or visitor < 0 or used % 1 ~= 0 or visitor % 1 ~= 0 or used > ${GLOBAL_LIMIT} or visitor > ${IP_LIMIT} then return {-2, 0, 0, resets} end
if ARGV[2] == 'reserve' then
  if used + ${PER_UPLOAD} > ${GLOBAL_LIMIT} or visitor + ${PER_UPLOAD} > ${IP_LIMIT} then return {0, ${GLOBAL_LIMIT}-used, ${IP_LIMIT}-visitor, resets} end
  used = used + ${PER_UPLOAD}
  visitor = visitor + ${PER_UPLOAD}
  redis.call('HSET', key, 'used', used, ARGV[1], visitor)
  redis.call('EXPIREAT', key, resets + 86400)
end
return {1, ${GLOBAL_LIMIT}-used, ${IP_LIMIT}-visitor, resets}
`;
export function createQuotaStore({url,token,fetcher=fetch}){
 const endpoint=new URL(url);
 if(endpoint.protocol!=='https:'||!endpoint.hostname.endsWith('.upstash.io')||endpoint.username||endpoint.password||endpoint.port||endpoint.pathname!=='/'||endpoint.search||endpoint.hash)throw Error('Invalid storage configuration');
 return async(visitor,reserve=false)=>{
  if(!/^[a-f0-9]{64}$/.test(visitor))throw Error('Invalid visitor identity');
  // Redis time and one atomic EVAL prevent clock skew and concurrent overspend.
  // Never retry uncertain reservations or release them after provider failures.
  const response=await fetcher(endpoint.href,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(['EVAL',RESERVE_SCRIPT,'1',LEDGER_KEY,'ip:'+visitor,reserve?'reserve':'status']),signal:AbortSignal.timeout(5000),redirect:'error'});
  if(!response.ok)throw Error('Storage unavailable');
  const data=await response.json(),result=data.result;
  if(data.error||!Array.isArray(result)||result.length!==4||!result.every(Number.isSafeInteger)||![-2,0,1].includes(result[0])||result[1]<0||result[1]>GLOBAL_LIMIT||result[2]<0||result[2]>IP_LIMIT||result[3]<=0)throw Error('Invalid storage response');
  if(result[0]===-2)throw Error('Upload budget is invalid');
  return {reserved:reserve&&result[0]===1,remaining:Math.min(result[1],result[2]),globalRemaining:result[1],visitorRemaining:result[2],perUpload:PER_UPLOAD,resetsAt:new Date(result[3]*1000).toISOString(),quotaPeriod:'day',timeZone:'Africa/Johannesburg'};
 };
}
