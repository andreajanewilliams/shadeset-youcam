import test from 'node:test';
import assert from 'node:assert/strict';
import sharp from 'sharp';
import {createHostedHandler,hostedPhoto,hostedConfig,clientIP} from '../hosted-upload.js';
import {createQuotaStore,LEDGER_KEY,RESERVE_SCRIPT} from '../hosted-quota.js';
import {makeIdentity} from '../src/approval.js';
import {renderRecipe} from '../src/previews.js';
import {coreRecipes as recipes,colours} from '../src/catalogue.js';
import {personalPreviewSet} from '../src/upload-ui.js';

const cfg={enabled:true,vercel:true,key:'test-key',secret:'test-secret-'.repeat(4),origin:'https://shadeset.example',url:'https://test.upstash.io',token:'test-token'};
const image=()=>sharp({create:{width:128,height:128,channels:3,background:'white'}}).png().toBuffer();
// Model the Redis atomic EVAL transport; production script is also exercised separately.
function database(){
 const hash=new Map([['used',0]]);let calls=0;
 const fetcher=async(url,options)=>{
  assert.equal(url,'https://test.upstash.io/');assert.equal(options.headers.Authorization,'Bearer test-token');
  const command=JSON.parse(options.body);
  assert.deepEqual(command.slice(0,4),['EVAL',RESERVE_SCRIPT,'1',LEDGER_KEY]);calls++;
  const field=command[4],reserve=command[5]==='reserve';
  let used=hash.get('used'),visitor=hash.get(field)||0;
  if(used===undefined||used<0||used>10)return Response.json({result:[-2,0,0,1793743200]});
  if(reserve){
   if(used+3>10||visitor+3>3)return Response.json({result:[0,10-used,3-visitor,1793743200]});
   used+=3;visitor+=3;hash.set('used',used);hash.set(field,visitor);
  }
  return Response.json({result:[1,10-used,3-visitor,1793743200]});
 };
 return {hash,fetcher,calls:()=>calls};
}
function fixture(overrides={}){
 const db=database();let renders=0;
 const options={config:()=>cfg,storeFactory:c=>createQuotaStore({...c,fetcher:db.fetcher}),render:async()=>{renders++;return [];},...overrides};
 const handler=()=>createHostedHandler(options);
 async function session(handle=handler(),ip='203.0.113.1'){
  const response=await handle(new Request(cfg.origin+'/api/upload/status',{headers:{'x-vercel-forwarded-for':ip}}));
  return {ip,cookie:response.headers.get('set-cookie')?.split(';')[0],data:await response.json()};
 }
 const upload=(s,bytes,headers={})=>new Request(cfg.origin+'/api/upload',{method:'POST',headers:{'x-vercel-forwarded-for':s.ip,Origin:cfg.origin,Cookie:s.cookie||'','X-Upload-Token':s.data.token||'','X-Photo-Consent':'yes','Content-Type':'image/png',...headers},body:bytes});
 return {db,handler,session,upload,renders:()=>renders};
}

test('hosted uploads fail closed for kill switch, missing key, missing storage and missing session secret',async()=>{
 for(const patch of [{enabled:false},{key:''},{url:''},{token:''},{secret:''}]){
  const f=fixture({config:()=>({...cfg,...patch})}),s=await f.session();
  assert.equal(s.data.enabled,false);assert.equal(s.data.remaining,0);assert.match(s.data.message,/sample still works/);
  assert.equal((await f.handler()(f.upload(s,await image()))).status,503);assert.equal(f.renders(),0);assert.equal(f.db.calls(),0);
 }
 assert.equal(hostedConfig({YOUCAM_UPLOADS_ENABLED:'0',YOUCAM_API_KEY:'test'}).enabled,false);
});
test('missing ledger or broken storage disables uploads without any provider calls',async()=>{
 const f=fixture();f.db.hash.delete('used');assert.equal((await f.session()).data.enabled,false);assert.equal(f.renders(),0);
 const g=fixture({storeFactory:()=>async()=>{throw Error('secret storage error');}}),s=await g.session();
 assert.equal(s.data.enabled,false);assert.equal(JSON.stringify(s.data).includes('secret storage error'),false);
});
test('concurrent separate instances enforce ten daily renders globally and three per IP',async()=>{
 const f=fixture(),sessions=await Promise.all(Array.from({length:8},(_,i)=>f.session(f.handler(),`203.0.113.${i+1}`))),photo=await image();
 const responses=await Promise.all(sessions.map(s=>f.handler()(f.upload(s,photo))));
 assert.equal(responses.filter(r=>r.status===200).length,3);assert.equal(f.renders(),3);assert.equal(f.db.hash.get('used'),9);
 const later=await f.session();assert.equal(later.data.enabled,false);assert.ok(later.data.remaining<3);
 const g=fixture(),s=await g.session();
 const same=await Promise.all([g.handler()(g.upload(s,photo)),g.handler()(g.upload(s,photo))]);
 assert.deepEqual(same.map(r=>r.status).sort(),[200,429]);assert.equal(g.db.hash.get('used'),3);assert.equal(g.renders(),1);
});
test('invalid image, origin, token, cookie or consent consumes no quota',async()=>{
 const f=fixture(),s=await f.session(),photo=await image();
 for(const headers of [{Origin:'https://evil.example'},{'X-Upload-Token':'bad'},{Cookie:s.cookie+'bad'},{'X-Photo-Consent':'no'}])assert.ok((await f.handler()(f.upload(s,photo,headers))).status>=400);
 assert.equal((await f.handler()(f.upload(s,Buffer.from('not an image')))).status,415);
 assert.equal((await f.handler()(f.upload(s,photo,{'Content-Length':String(4*1024*1024+1)}))).status,413);
 assert.equal(f.renders(),0);assert.equal(f.db.hash.get('used'),0);
});
test('failed provider work retains durable reservation across handler recreation without retries',async()=>{
 let calls=0;const f=fixture({render:async()=>{calls++;throw Error('private provider detail');}}),s=await f.session();
 const response=await f.handler()(f.upload(s,await image()));assert.equal(response.status,502);
 assert.equal((await response.text()).includes('private provider detail'),false);assert.equal(f.db.hash.get('used'),3);
 assert.equal((await f.handler()(f.upload(s,await image()))).status,429);assert.equal(calls,1);
});
test('uncertain storage reservation fails closed and is never retried',async()=>{
 let writes=0,renders=0;
 const f=fixture({storeFactory:()=>async(visitor,reserve)=>{if(reserve){writes++;throw Error('timeout after commit');}return {remaining:3};},render:async()=>{renders++;}}),s=await f.session();
 assert.equal((await f.handler()(f.upload(s,await image()))).status,503);assert.equal(writes,1);assert.equal(renders,0);
});
test('hosted image roundtrip preserves byte-bound approvals, strips metadata and stays below payload limit',async()=>{
 const input=await sharp({create:{width:1024,height:1024,channels:4,background:'#897064'}}).png().withMetadata().toBuffer();
 const photo=await hostedPhoto(input,'image/png'),meta=await sharp(photo).metadata();
 assert.equal(meta.width,480);assert.equal(meta.hasAlpha,false);assert.equal(meta.exif,undefined);assert.equal(meta.icc,undefined);
 const f=fixture({render:async bytes=>Promise.all(recipes.map(async recipe=>({recipeId:recipe.id,output:photo.toString('base64'),identity:await makeIdentity({photo:new Uint8Array(bytes),recipe:renderRecipe(recipe,colours),output:new Uint8Array(photo)})})))}),s=await f.session();
 const response=await f.handler()(f.upload(s,input)),body=await response.json();assert.equal(response.status,200);
 assert.equal((await personalPreviewSet(body,recipes,colours)).length,3);assert.ok(JSON.stringify(body).length<4*1024*1024);
});

test('exhausted or corrupt daily global counters fail closed',async()=>{
 for(const used of [9,10,12]){
  const f=fixture();f.db.hash.set('used',used);
  const s=await f.session();assert.equal(s.data.enabled,false);
  assert.ok((await f.handler()(f.upload(s,await image()))).status>=400);
  assert.equal(f.renders(),0);assert.equal(f.db.hash.get('used'),used);
 }
});

 test('new cookies and spoofed generic forwarded headers cannot reset an IP allowance',async()=>{
 const f=fixture(),a=await f.session(),b=await f.session(),photo=await image();
 assert.notEqual(a.cookie,b.cookie);
 assert.equal((await f.handler()(f.upload(a,photo))).status,200);
 assert.equal((await f.handler()(f.upload(b,photo,{'x-forwarded-for':'198.51.100.4'}))).status,429);
 assert.equal(f.renders(),1);
 });
 test('trusted Vercel IP is mandatory and normalises equivalent addresses',async()=>{
 const request=ip=>new Request(cfg.origin,{headers:{'x-vercel-forwarded-for':ip}});
 for(const ip of ['', 'bad', '1.2.3.4, 5.6.7.8'])assert.throws(()=>clientIP(request(ip),cfg));
 assert.throws(()=>clientIP(request('1.2.3.4'),{...cfg,vercel:false}));
 assert.equal(clientIP(request('2001:0db8:0:0:0:0:0:1'),cfg),'2001:db8::1');
 assert.equal(clientIP(request('::ffff:192.0.2.1'),cfg),'192.0.2.1');
 const f=fixture({config:()=>({...cfg,vercel:false})});
 assert.equal((await f.session()).data.enabled,false);assert.equal(f.db.calls(),0);
 });

 test('Vercel Marketplace Redis variables are supported without using read-only tokens',()=>{
 const c=hostedConfig({KV_REST_API_URL:'https://test.upstash.io',KV_REST_API_TOKEN:'write',KV_REST_API_READ_ONLY_TOKEN:'read'});
 assert.equal(c.url,'https://test.upstash.io');assert.equal(c.token,'write');
 assert.equal(hostedConfig({KV_REST_API_READ_ONLY_TOKEN:'read'}).token,'');
 const explicit=hostedConfig({UPSTASH_REDIS_REST_URL:'https://dedicated.upstash.io',UPSTASH_REDIS_REST_TOKEN:'dedicated',KV_REST_API_URL:'https://test.upstash.io',KV_REST_API_TOKEN:'write'});
 assert.equal(explicit.url,'https://dedicated.upstash.io');assert.equal(explicit.token,'dedicated');
 });
