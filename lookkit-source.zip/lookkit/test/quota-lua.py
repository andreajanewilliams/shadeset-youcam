"""Execute the production quota Lua with a controlled Redis command adapter.
Run with Python + lupa installed; no network or provider calls are made.
"""
from datetime import datetime
from pathlib import Path
import subprocess
from lupa import LuaRuntime

script = subprocess.check_output(['node', '--input-type=module', '-e', "import {RESERVE_SCRIPT} from './hosted-quota.js';process.stdout.write(RESERVE_SCRIPT)"], text=True)
lua = LuaRuntime(unpack_returned_tuples=True)
store, expiries = {}, {}
now = int(datetime.fromisoformat('2026-11-02T21:59:59+00:00').timestamp())
def call(command, *args):
    if command == 'TIME': return lua.table_from([str(now), '0'])
    if command == 'HGET': return store.get(args[0], {}).get(args[1])
    if command == 'HSET':
        bucket = store.setdefault(args[0], {})
        for i in range(1, len(args), 2): bucket[args[i]] = args[i+1]
        return 1
    if command == 'EXPIREAT': expiries[args[0]] = args[1]; return 1
    raise AssertionError(command)
lua.globals().redis = lua.table_from({'call': call})
lua.globals().KEYS = lua.table_from(['lookkit:andrea:daily-renders:v1'])
def run(visitor, reserve=True):
    lua.globals().ARGV = lua.table_from(['ip:'+visitor, 'reserve' if reserve else 'status'])
    result = lua.execute(script)
    return [result[i] for i in range(1, 5)]
assert run('a', False)[1:3] == [10, 3]
assert not store
assert run('a')[1:3] == [7, 0]
assert run('a')[0] == 0
assert run('b')[1:3] == [4, 0]
assert run('c')[1:3] == [1, 0]
assert run('d')[0] == 0
old = {k:dict(v) for k,v in store.items()}
now += 1  # Exactly midnight SAST, using Redis clock.
assert run('a', False)[1:3] == [10, 3]
assert run('a')[1:3] == [7, 0]
assert all(store[k] == v for k,v in old.items())
assert len(store) == 2
assert all(expiry > now for expiry in expiries.values())
newkey = next(k for k in store if k not in old)
for broken in ['bad', -1, 1.5, 11]:
    store[newkey]['used'] = broken
    assert run('b')[0] == -2
store[newkey]['used'] = 3
for broken in ['bad', -1, 1.5, 4]:
    store[newkey]['ip:b'] = broken
    assert run('b')[0] == -2
print('Production Lua passed: global/IP caps, no writes on status, midnight SAST reset, old-day preservation, expiry and corrupt-counter rejection.')
