import {mkdir,cp} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for(const name of ['index.html','src','public']) await cp(name,`dist/${name}`,{recursive:true});
