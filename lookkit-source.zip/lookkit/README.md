# LookKit

Explore seven eye-makeup looks, approve your favourites and find a lowest-cost complete basket within the dated catalogue. The three core looks total R550 versus R743 for separately optimised kits; all seven total R918 versus R1,715. Both comparisons include an estimated R95 local delivery charge. Prices are a 26 October 2026 ZAR snapshot.

## Run

Requires Node.js 20.9 or later.

```sh
npm ci
npm test
npm run dev
```

Open http://127.0.0.1:5173. The sample needs no API key. Seven genuine saved YouCam renders share a synthetic face. Nine colour references approximate retailer swatches; previews do not guarantee physical colour accuracy. There is no checkout or live-stock guarantee.

## Personal photos and hosting

Vercel uses `node build.mjs` and serves `dist`. Required server-only variables: `YOUCAM_API_KEY`, `YOUCAM_UPLOADS_ENABLED=1`, `UPLOAD_SESSION_SECRET` (stable random secret, at least 32 characters), `UPLOAD_ALLOWED_ORIGIN` (exact HTTPS origin), `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`. Missing configuration disables uploads.

The hosted allowance is 10 renders globally and 3 per IP each day, resetting at midnight SAST. Each photo reserves three renders, allowing at most three complete batches per day. Failed work remains counted. Redis stores counters and hashed IP identities, not photographs. Shared public IPs share an allowance. Users explicitly consent before sending photos to YouCam. Personal photos produce the three core looks.

The local development server uses separate in-memory limits and must not be publicly exposed. Do not commit credentials. Application licensing is in LICENSE; bundled fonts retain their own licence notices.
